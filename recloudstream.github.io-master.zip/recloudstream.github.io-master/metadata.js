module.exports = {
    title: `Recloudstream`,
    siteUrl: `https://recloudstream.github.io`
}